package main

import (
	"fmt"
	"goblockchain/utils"
)

func main() {
	fmt.Println(utils.GetHost())
}
